nbr1 = float(input("Veuillez saisir un nombre:"))
nbr2 = float(input("Veuillez saisir un nombre:"))
nbr3 = float(input("Veuillez saisir un nombre:"))
if nbr1 <= nbr2 <= nbr3:
    print("Les nombres sont triés en ordre croissant")
else:
    print("les nombres ne sont triés en ordre décroissant")