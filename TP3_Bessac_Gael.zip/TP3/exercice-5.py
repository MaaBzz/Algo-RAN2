nbr = float(input("Saississez un nombre:"))
if nbr > 0:
    print("Positif")
elif nbr == 0:
    print("Nul")
else:
    print("Négatif")