x = float(input("veuillez saisir un nombre:"))

cote = x * x
print("Le résultat est de",cote)