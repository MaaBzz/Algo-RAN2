année = int(input("veuillez saisir une année de naissance:"))

année_actuel = 2023
age = année_actuel - année
print("Votre age est", age)