prénom = str(input("veuillez saisir un prénom:"))

print("Hello",prénom)