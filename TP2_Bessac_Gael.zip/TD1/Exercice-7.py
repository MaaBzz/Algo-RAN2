longueur = float(input("veuillez saisir un nombre:"))
largeur = float(input("veuillez saisir un nombre:"))
hauteur = float(input("veuillez saisir un nombre:"))

volume = longueur * largeur * hauteur
print("Le volume est de",volume)