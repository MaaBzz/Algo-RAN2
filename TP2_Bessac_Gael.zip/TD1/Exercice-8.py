ht = float(input("veuillez saisir un nombre:"))
quantité = float(input("veuillez saisir un nombre:"))

montant_ht = ht * quantité
remise = 15

calcul_remise = (montant_ht / 100) * remise
prix_remise = montant_ht - calcul_remise
TVA = 20
calcul_TVA = (prix_remise / 100) * TVA
Prix_TTC = calcul_TVA + prix_remise
print("Le prix TTC est de", Prix_TTC,"€")