francais = float(input("veuillez saisir un nombre:"))
math = float(input("veuillez saisir un nombre:"))
geometrie = float(input("veuillez saisir un nombre:"))
informatique = float(input("veuillez saisir un nombre:"))

moy = (francais + math + geometrie + informatique) / 4 
print("La moyenne est de", moy)
