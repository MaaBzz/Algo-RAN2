a = int(input("veuillez saisir un nombre:"))
b = int(input("veuillez saisir un nombre:"))
somme = a + b
print("La somme est de",somme)

soustraction = a - b
print("Le résultat est de",soustraction)

division = a / b
print("Le résultat est de",division)

multiplication = a * b
print("Le résultat est de",multiplication)