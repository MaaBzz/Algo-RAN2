x = float(input("veuillez saisir un nombre:"))

double = x * 2
print("Le résultat est de",double)